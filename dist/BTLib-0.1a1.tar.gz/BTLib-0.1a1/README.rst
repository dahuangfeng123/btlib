=======
BTLib
=======
--------------------
An Alternate Novel Hosting App
--------------------

Multi-Lingual Web Novel hosting platform, written in python for the Django framework.

Initiated as an investigation into potential alternatives to mediaWiki for serving up translations of novels.
