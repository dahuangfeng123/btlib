from django.contrib import admin
from btlib.models import *

admin.site.register(Language)
admin.site.register(Series)
admin.site.register(Volume)
admin.site.register(Chapter)
admin.site.register(Translation)
admin.site.register(VolTrans)
admin.site.register(SeriesTrans)
admin.site.register(Image)
