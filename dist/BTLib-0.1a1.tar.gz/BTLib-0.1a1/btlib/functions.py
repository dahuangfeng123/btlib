

def btParse(text):
    pass
